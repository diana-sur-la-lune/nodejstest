import { postRegister } from '../modules/api/api.js';
import {
	renderLoader,
	prependItemToElement,
	removeLoaderFromElement,
	verifyEmail,
	renderMsgToBody,
} from '../utils/utils.js';

const params = 'v1/auth/register';

const form = document.getElementById('register');
const main = document.querySelector('main');

form.addEventListener('submit', (e) => {
	e.preventDefault();
	prependItemToElement(main, renderLoader());

	const fullName = form.elements.fullName.value;
	const email = form.elements.email.value;
	const password = form.elements.password.value;
	const repPassword = form.elements.repPassword.value;

	if (!fullName || !email || !password || !repPassword) {
		renderMsgToBody('Please fill all fields');
		removeLoaderFromElement(main);
		return;
	}

	if (!verifyEmail(email)) {
		removeLoaderFromElement(main);
		renderMsgToBody('Please enter a valid email');
		return;
	}

	if (password !== repPassword) {
		renderMsgToBody("Provided password's do not match, please try again");
		removeLoaderFromElement(main);
		return;
	}

	postRegister(params, { fullName, email, password }).finally(() => {
		removeLoaderFromElement(main);
	});
});
