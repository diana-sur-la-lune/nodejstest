import { postData, getAuthedData } from "../modules/api/api.js";
import {
  renderLoader,
  prependItemToElement,
  removeLoaderFromElement,
  renderMsgToBody,
  checkAuth,
} from "../utils/utils.js";

checkAuth();

const params = "v1/accounts";

const list = document.querySelector(".groups__list");
const main = document.querySelector("main");
const joinForm = document.getElementById("joinGroup");
const addForm = document.getElementById("addGroup");

const renderItemsToList = (data) => {
  if (data?.length === 0) {
    renderMsgToBody("You have no groups");
    return;
  }
  data.forEach((item) => {
    const li = document.createElement("li");
    const a = document.createElement("a");
    const h4 = document.createElement("h4");
    const p = document.createElement("p");

    a.href = `bills.html?group_id=${item.group_id}`;
    h4.textContent = `ID: ${item.group_id}`;
    p.textContent = item.name;

    a.append(h4, p);
    li.appendChild(a);
    list.appendChild(li);
  });
};

const init = () => {
  prependItemToElement(main, renderLoader());
  getAuthedData(params)
    .then(renderItemsToList)
    .finally(() => {
      removeLoaderFromElement(main);
    });
};

init();

joinForm.addEventListener("submit", (e) => {
  e.preventDefault();
  prependItemToElement(main, renderLoader());

  const groupId = e.target.elements.groupId.value;

  postData(params, { group_id: groupId }).finally(() => {
    removeLoaderFromElement(main);
  });
});

addForm.addEventListener("submit", (e) => {
  e.preventDefault();
  prependItemToElement(main, renderLoader());

  const groupName = e.target.elements.groupName.value;

  postData(params, { name: groupName }).finally(() => {
    removeLoaderFromElement(main);
    init();
  });
});
