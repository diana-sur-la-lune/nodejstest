import { postLogin } from '../modules/api/api.js';
import {
	renderLoader,
	prependItemToElement,
	removeLoaderFromElement,
	renderMsgToBody,
	verifyEmail,
} from '../utils/utils.js';

const params = 'v1/auth/login';

const form = document.getElementById('login');
const main = document.querySelector('main');

form.addEventListener('submit', (e) => {
	e.preventDefault();
	prependItemToElement(main, renderLoader());

	const email = form.elements.email.value.trim();
	const password = form.elements.password.value.trim();

	if (!email || !password) {
		removeLoaderFromElement(main);
		renderMsgToBody('Please fill in all fields');
		return;
	}

	if (!verifyEmail(email)) {
		removeLoaderFromElement(main);
		renderMsgToBody('Please enter a valid email');
		return;
	}

	postLogin(params, { email, password }).finally(() => {
		removeLoaderFromElement(main);
	});
});
