import { postData, getAuthedData } from '../modules/api/api.js';
import { renderMsgToBody, renderLoader, prependItemToElement, removeLoaderFromElement, checkAuth } from '../utils/utils.js';

checkAuth();

const baseParams = 'v1/bills';

const queryParams = window.location.search;
const groupId = queryParams.split('=')[1];

const form = document.getElementById('add-bill');
const tBody = document.querySelector('.bills__table-body');
const main = document.querySelector('main');

const renderItemsToTableBody = (data) => {
	if (data?.length === 0) {
		renderMsgToBody('You have no bills in this group');
		return;
	}
	data.forEach((item) => {
		const tr = document.createElement('tr');
		const tdId = document.createElement('td');
		const tdDescription = document.createElement('td');
		const tdAmount = document.createElement('td');

		tdId.textContent = item.id;
		tdDescription.textContent = item.description;
		tdAmount.textContent = `$${item.amount}`;

		tr.append(tdId, tdDescription, tdAmount);
		tBody.appendChild(tr);
	});
};

const init = () => {
	prependItemToElement(main, renderLoader());
	getAuthedData(baseParams + queryParams)
		.then(renderItemsToTableBody)
		.finally(() => {
			removeLoaderFromElement(main);
		});
};

init();

form.addEventListener('submit', (e) => {
	e.preventDefault();
	prependItemToElement(main, renderLoader());

	const amount = e.target.amount.value;
	const description = e.target.description.value;

	postData(baseParams, { group_id: groupId, amount, description }).finally(() => {
		removeLoaderFromElement(main);
	});
});
