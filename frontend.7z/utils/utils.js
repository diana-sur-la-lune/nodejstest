export const renderMsgToBody = (msg) => {
	const body = document.querySelector('body');
	const div = document.createElement('div');
	div.classList.add('msg');

	const p = document.createElement('p');
	p.textContent = msg;

	div.appendChild(p);
	body.appendChild(div);

	setTimeout(() => {
		document.querySelector('.msg').remove();
	}, 8000);
};

export const renderLoader = () => {
	const loading = document.createElement('div');
	loading.classList.add('loading');
	const spinner = document.createElement('div');
	spinner.classList.add('lds-hourglass');
	loading.appendChild(spinner);
	return loading;
};

export const removeLoaderFromElement = (element) => {
	const loader = element.querySelector('.loading');
	if (loader) {
		loader.remove();
	}
};

export const prependItemToElement = (parent, el) => {
	parent.insertBefore(el, parent.firstChild);
};

export const checkAuth = () => {
	if (!localStorage.getItem('token')) {
		window.location.href = '/index.html';
		return;
	}
};

export const verifyEmail = (email) => {
	const re =
		/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	return re.test(String(email).toLowerCase());
};
