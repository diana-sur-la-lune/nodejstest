import { renderMsgToBody } from "../../utils/utils.js";

const url = "http://127.0.0.1:8000/";

export const getAuthedData = async (params) => {
  try {
    return await fetch(`${url}${params}`, {
      headers: {
        authorization: "Bearer " + localStorage.getItem("token"),
      },
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.err) {
          return renderMsgToBody(data.err);
        }
        return data;
      });
  } catch (err) {
    return renderMsgToBody("Error occurred while connecting to the server");
  }
};

export const postData = async (params, body) => {
  try {
    return await fetch(`${url}${params}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorization: "Bearer " + localStorage.getItem("token"),
      },
      body: JSON.stringify(body),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.err) {
          return renderMsgToBody(data.err);
        }
        window.location.reload();
      });
  } catch (err) {
    return renderMsgToBody("Error occurred while connecting to the server");
  }
};

export const postLogin = async (params, body) => {
  try {
    return await fetch(`${url}${params}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.err) {
          return renderMsgToBody(data.err);
        }
        localStorage.setItem("token", data.token);
        location.href = "/accounts.html";
      });
  } catch (err) {
    return renderMsgToBody("Error occurred while connecting to the server");
  }
};

export const postRegister = async (params, body) => {
  console.log("tjt");
  try {
    return await fetch(`${url}${params}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.err) {
          return renderMsgToBody(data.err);
        }
        location.href = "/index.html";
      });
  } catch (err) {
    return renderMsgToBody("Error occurred while connecting to the server");
  }
};
