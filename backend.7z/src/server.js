const express = require('express');
const cors = require('cors');

const { port } = require('./config');

const app = express();

app.use(express.json());
app.use(cors());

const { auth, bills, accounts } = require('./routes/v1');

app.use('/v1/auth', auth);
app.use('/v1/bills', bills);
app.use('/v1/accounts', accounts);

app.get('/', (req, res) => res.send({ msg: 'Version 1.0.0' }));

app.all('*', (req, res) => {
  res.status(404).send({ err: 'Not found' });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
