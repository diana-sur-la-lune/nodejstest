const { postLogin, postRegister } = require('./auth');
const { getBillsByGroupId, postNewBillToGroup } = require('./bills');
const { postToUserAccount, getUserAccounts } = require('./accounts');

module.exports = {
  postLogin,
  postRegister,
  getBillsByGroupId,
  postNewBillToGroup,
  postToUserAccount,
  getUserAccounts,
};
