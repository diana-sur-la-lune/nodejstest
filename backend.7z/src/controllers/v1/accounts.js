const mysql = require("mysql2/promise");
const Joi = require("joi");

const { dbConfig } = require("../../config");

const getUserAccounts = async (req, res) => {
  const userId = req.user.id;
  try {
    const query = `SELECT sb_accounts.group_id, sb_groups.name FROM sb_accounts LEFT JOIN sb_groups ON sb_accounts.group_id = sb_groups.id WHERE sb_accounts.user_id = ${userId}`;

    const con = await mysql.createConnection(dbConfig);
    const [data] = await con.execute(query);
    await con.end();

    return res.send(data);
  } catch (err) {
    return res.status(500).send({ err: "Server error" });
  }
};

const postToUserAccount = async (req, res) => {
  const userAccountPostSchema = Joi.object({
    group_id: Joi.number(),
    name: Joi.string(),
  });

  let userInput = req.body;
  const userId = req.user.id;

  try {
    userInput = await userAccountPostSchema.validateAsync(userInput);
  } catch (err) {
    return res
      .status(400)
      .send({ err: "Incorrect parameters, please try again" });
  }

  const groupExists = async (group_id) => {
    try {
      const query = `SELECT * from sb_groups WHERE sb_groups.id = ${mysql.escape(
        group_id
      )}`;
      const con = await mysql.createConnection(dbConfig);
      const [data] = await con.execute(query);
      await con.end();

      return data.length > 0;
    } catch (err) {
      return res.status(500).send({ err: "Server error" });
    }
  };

  const userAlreadyHasGroup = async (group_id) => {
    try {
      const query = `SELECT * from sb_accounts WHERE sb_accounts.group_id = ${mysql.escape(
        group_id
      )} AND sb_accounts.user_id = ${userId}`;
      const con = await mysql.createConnection(dbConfig);
      const [data] = await con.execute(query);
      await con.end();

      return data.length > 0;
    } catch (err) {
      return res.status(500).send({ err: "Server error" });
    }
  };

  if (userInput.group_id) {
    try {
      if (!(await groupExists(userInput.group_id))) {
        return res.status(400).send({ err: "Group does not exist" });
      }
      if (await userAlreadyHasGroup(userInput.group_id)) {
        return res.status(400).send({ err: "Group is already added" });
      }
      const query = `INSERT INTO sb_accounts (group_id, user_id) VALUES (${mysql.escape(
        userInput.group_id
      )}, ${mysql.escape(userId)})`;
      const con = await mysql.createConnection(dbConfig);
      const [data] = await con.execute(query);
      await con.end();

      return data.affectedRows > 0
        ? res.send({ msg: "Account has been added successfully" })
        : res
            .status(400)
            .send({ err: "Account wasn't added, please try again" });
    } catch (err) {
      return res.status(500).send({ err: "Server error" });
    }
  } else if (userInput.name) {
    try {
      const groupQuery = `INSERT INTO sb_groups (name) VALUES (${mysql.escape(
        userInput.name
      )})`;
      const con = await mysql.createConnection(dbConfig);
      const [data] = await con.execute(groupQuery);
      if (data.affectedRows > 0) {
        const groupId = data.insertId;

        const query = `INSERT INTO sb_accounts (group_id, user_id) VALUES (${mysql.escape(
          groupId
        )}, ${mysql.escape(userId)})`;
        const [data2] = await con.execute(query);
        await con.end();
        return data2.affectedRows > 0
          ? res.send({ msg: "Group was created successfully" })
          : res
              .status(400)
              .send({ err: "Account wasn't added, please try again" });
      } else {
        await con.end();
        return res
          .status(400)
          .send({ err: "Group wasn't created, please try again" });
      }
    } catch (err) {
      console.log("err:", err);
      return res.status(500).send({ err: "Server error" });
    }
  }
};

module.exports = { getUserAccounts, postToUserAccount };
