const mysql = require("mysql2/promise");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const Joi = require("joi");

const { dbConfig, jwtSecret } = require("../../config");

const postRegister = async (req, res) => {
  const userRegisterSchema = Joi.object({
    fullName: Joi.string().trim().required(),
    email: Joi.string().email().trim().required(),
    password: Joi.string()
      .trim()
      .pattern(new RegExp("^[a-zA-Z0-9]{3,30}$"))
      .required(),
  });

  let userInput = req.body;

  try {
    userInput = await userRegisterSchema.validateAsync(userInput);
  } catch (err) {
    return res
      .status(400)
      .send({ err: "Incorrect parameters, please try again" });
  }

  const encryptedPassword = await bcrypt.hash(userInput.password, 10);

  const query = `INSERT INTO sb_users (full_name, email, password) VALUES (${mysql.escape(
    userInput.fullName
  )}, ${mysql.escape(userInput.email)}, '${encryptedPassword}')`;

  try {
    const con = await mysql.createConnection(dbConfig);
    const [data] = await con.execute(query);
    await con.end();

    return res.send(data);
  } catch (err) {
    console.log("error:", err);
    res.status(500).send({ err: "Server error:" });
  }
};

const postLogin = async (req, res) => {
  const userLoginSchema = Joi.object({
    email: Joi.string().email().trim().required(),
    password: Joi.string()
      .trim()
      .pattern(new RegExp("^[a-zA-Z0-9]{3,30}$"))
      .required(),
  });

  let userInput = req.body;

  try {
    userInput = await userLoginSchema.validateAsync(userInput);
  } catch (err) {
    return res.status(400).send(err.details[0].message);
  }

  const query = `SELECT * FROM sb_users WHERE email = ${mysql.escape(
    userInput.email
  )} LIMIT 1`;

  try {
    const con = await mysql.createConnection(dbConfig);
    const [data] = await con.execute(query);

    if (data.length === 0) {
      return res.status(400).send({ err: "No user found with this email" });
    }

    const isAuthed = bcrypt.compareSync(userInput.password, data[0].password);

    const token = jwt.sign(
      {
        id: data[0].id,
        email: data[0].email,
        fullName: data[0].full_name,
      },
      jwtSecret,
      {
        expiresIn: "24h",
      }
    );

    return isAuthed
      ? res.send({ token })
      : res.status(400).send({ err: "Invalid password" });
  } catch (err) {
    return res.status(500).send({ err: "Server error" });
  }
};
module.exports = { postRegister, postLogin };
