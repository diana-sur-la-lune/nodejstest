const auth = require('./auth');
const bills = require('./bills');
const accounts = require('./accounts');

module.exports = {
  auth,
  bills,
  accounts,
};
