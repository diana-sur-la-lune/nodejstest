const express = require('express');

const router = express.Router();

const { isLoggedIn } = require('../../middleware/isLoggedIn');

const {
  getBillsByGroupId,
  postNewBillToGroup,
} = require('../../controllers/v1');

router.get('/', isLoggedIn, getBillsByGroupId);

router.post('/', isLoggedIn, postNewBillToGroup);

module.exports = router;
