const express = require('express');

const router = express.Router();

const { isLoggedIn } = require('../../middleware/isLoggedIn');

const { getUserAccounts, postToUserAccount } = require('../../controllers/v1');

router.get('/', isLoggedIn, getUserAccounts);

router.post('/', isLoggedIn, postToUserAccount);

module.exports = router;
